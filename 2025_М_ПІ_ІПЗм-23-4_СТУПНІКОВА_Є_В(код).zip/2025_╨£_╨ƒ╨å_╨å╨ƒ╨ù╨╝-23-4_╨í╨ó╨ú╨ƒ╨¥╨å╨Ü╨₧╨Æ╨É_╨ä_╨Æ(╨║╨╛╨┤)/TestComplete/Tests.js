
function openHome() {
  Browsers.Item(btChrome).Run("https://www.demoblaze.com");
  Aliases.browser.pageDemoblaze.Loaded.WaitProperty("readyState", "complete", 5000);
}


function login(username, password) {
  Aliases.browser.pageDemoblaze.FindElement("//a[@id='login2']").Click();
  Aliases.browser.pageDemoblaze.WaitElement("//input[@id='loginusername']", 2000).SetText(username);
  Aliases.browser.pageDemoblaze.FindElement("//input[@id='loginpassword']").SetText(password);
  Aliases.browser.pageDemoblaze.FindElement("//button[text()='Log in']").Click();
}

function signup(username, password) {
  Aliases.browser.pageDemoblaze.FindElement("//a[@id='signin2']").Click();
  Aliases.browser.pageDemoblaze.WaitElement("//input[@id='sign-username']", 2000).SetText(username);
  Aliases.browser.pageDemoblaze.FindElement("//input[@id='sign-password']").SetText(password);
  Aliases.browser.pageDemoblaze.FindElement("//button[text()='Sign up']").Click();
}

function addToCart(productName) {
  Aliases.browser.pageDemoblaze.FindElement(`//a[text()='${productName}']`).Click();
  Aliases.browser.pageDemoblaze.FindElement("//a[text()='Add to cart']").Click();
}

function openCart() {
  Aliases.browser.pageDemoblaze.FindElement("//a[@id='cartur']").Click();
}

function clearCart() {
  openCart();
  let rows = Aliases.browser.pageDemoblaze.FindElements("//tr/td[text()]");
  for (let i = rows.length - 1; i >= 0; i--) {
    Aliases.browser.pageDemoblaze.FindElement("//a[text()='Delete']").Click();
    Delay(500);
  }
}

function TestSuite_Demoblaze() {
  // 1. Открытие главной страницы
  openHome();
  aqObject.CheckProperty(Aliases.browser.pageDemoblaze, "contentText", cmpContains, "PRODUCT STORE");

  aqObject.CheckProperty(Sys.Browser("chrome").Page("https://www.demoblaze.com").Title, "Text", cmpEqual, "STORE");


  let logo = Aliases.browser.pageDemoblaze.FindElement("//a[@id='nava']");
  aqObject.CheckProperty(logo, "VisibleOnScreen", cmpEqual, true);
  aqObject.CheckProperty(logo, "href", cmpContains, "index.html");


  let cats = Aliases.browser.pageDemoblaze.FindElements("//div[@id='itemc']");
  aqObject.CheckProperty(cats.length, "value", cmpGreater, 2);


  Aliases.browser.pageDemoblaze.FindElement("//a[text()='Phones']").Click();
  let phones = Aliases.browser.pageDemoblaze.FindElements("//div[contains(@class,'card')]");
  aqObject.CheckProperty(phones.length, "value", cmpGreater, 4);


  Aliases.browser.pageDemoblaze.FindElement("//a[text()='Samsung galaxy s6']").Click();
  aqObject.CheckProperty(Aliases.browser.pageDemoblaze.FindElement("//h2"), "contentText", cmpContains, "Samsung galaxy s6");

  aqObject.CheckProperty(Aliases.browser.pageDemoblaze.FindElement("//h2/following-sibling::h3"), "contentText", cmpContains, "$360");

  addToCart("Samsung galaxy s6");
  Sys.Browser("chrome").Page("*").OnAlert = function (alert) {
    let text = alert.text;
    Log.Check(text.indexOf("Product added") !== -1, "Alert text OK");
  };

  openCart();
  aqObject.CheckProperty(Aliases.browser.pageDemoblaze.FindElement("//td[text()='Samsung galaxy s6']"), "Exists", cmpEqual, true);

  Aliases.browser.pageDemoblaze.FindElement("//a[text()='Delete']").Click();
  Delay(500);
  aqObject.CheckProperty(Aliases.browser.pageDemoblaze.FindElement("//td[text()='Samsung galaxy s6']"), "Exists", cmpEqual, false);

  openHome();
  Aliases.browser.pageDemoblaze.FindElement("//a[text()='Contact']").Click();
  aqObject.CheckProperty(Aliases.browser.pageDemoblaze.FindElement("//h5[text()='New message']"), "Exists", cmpEqual, true);


  Aliases.browser.pageDemoblaze.FindElement("//a[text()='About us']").Click();
  aqObject.CheckProperty(Aliases.browser.pageDemoblaze.FindElement("//div[@id='videoModal']"), "VisibleOnScreen", cmpEqual, true);

  login("123", "123");
  aqObject.CheckProperty(Aliases.browser.pageDemoblaze.FindElement("//a[@id='logout2']"), "Exists", cmpEqual, true);



  openHome();
  login("wronguser", "wrongpass");
  Sys.Browser("chrome").Page("*").OnAlert = function (alert) {
    let text = alert.text;
    Log.Check(text.indexOf("Wrong password") !== -1, "Alert indicates failure");
  };

  clearCart();
  openCart();


  aqObject.CheckProperty(Aliases.browser.pageDemoblaze.FindElements("//tr/td[text()]").length, "value", cmpEqual, 0);
}

// Chaos Engineering: втручання в процес
function chaosTest_NetworkInterruptionDuringAddToCart() {
  Log.AppendFolder("Chaos Test: Network Interruption During Add to Cart");

  openHome();
  Aliases.browser.pageDemoblaze.FindElement("//a[text()='Laptops']").Click();
  Delay(1000);
  Aliases.browser.pageDemoblaze.FindElement("//a[text()='Sony vaio i5']").Click();

  // Імітуємо відключення інтернету
  Log.Message("Симулюємо втрату з'єднання");
  Runner.CallMethod("WshShell.Run", "cmd.exe /c ipconfig /release", 0, true); // Відключення IP
  
  Delay(3000);

  try {
    Aliases.browser.pageDemoblaze.FindElement("//a[text()='Add to cart']").Click();
    Log.Warning("Тест: Кнопка натиснута попри втрату мережі");
  } catch (err) {
    Log.Check(true, "Очікуваний краш або відсутність відповіді — OK");
  }

  Log.Message("Відновлюємо мережу");
  Runner.CallMethod("WshShell.Run", "cmd.exe /c ipconfig /renew", 0, true);
  Delay(5000);

  openCart();
  let items = Aliases.browser.pageDemoblaze.FindElements("//td[text()='Sony vaio i5']");
  Log.Message("Кількість товарів у корзині: " + items.length);
  Log.Check(items.length === 0, "Товар не додався, як і очікувалось при втраті мережі");

  Log.PopLogFolder();
}


function Test() {
  TestedApps.Empty; 
  TestSuite_Demoblaze();
}
chaosTest_NetworkInterruptionDuringAddToCart();

