// @ts-check
import { test, expect } from '@playwright/test';

test('Open homepage and verify title', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await expect(page).toHaveTitle('STORE');
});

test('Check product categories', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  const categories = ['Phones', 'Laptops', 'Monitors'];
  for (const category of categories) {
    await expect(page.getByText(category)).toBeVisible();
  }
});

test('Open Phones category', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('text=Phones');
  await expect(page.locator('.hrefch')).toHaveCount(7); // Перевірка кількості телефонів
});

test('View product details (Samsung Galaxy S6)', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('text=Samsung galaxy s6');
  await expect(page.locator('.name')).toHaveText('Samsung galaxy s6');
  await expect(page.locator('.price-container')).toContainText('$360');
});

test('Add product to cart', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('text=Samsung galaxy s6');
  await page.click('text=Add to cart');
  await page.waitForEvent('dialog', dialog => dialog.message().includes('Product added'));
});

test('Check cart after adding product', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('text=Samsung galaxy s6');
  await page.click('text=Add to cart');
  await page.click('#cartur');
  await expect(page.locator('.success')).toContainText('Samsung galaxy s6');
});

test('Remove product from cart', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('text=Samsung galaxy s6');
  await page.click('text=Add to cart');
  await page.click('#cartur');
  await page.click('text=Delete');
  await expect(page.locator('.success')).toHaveCount(0);
});

test('Login with valid credentials', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('#login2');
  await page.fill('#loginusername', '123');
  await page.fill('#loginpassword', '123');
  await page.click('button:has-text("Log in")');
  await expect(page.locator('#nameofuser')).toContainText('Welcome testuser');
});

test('Login with invalid credentials', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('#login2');
  await page.fill('#loginusername', 'wronguser');
  await page.fill('#loginpassword', 'wrongpass');
  await page.click('button:has-text("Log in")');
  await page.on('dialog', dialog => {
    expect(dialog.message()).toContain('Wrong password.');
  });
});

test('Register new user', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('#signin2');
  const randomUser = `testuser_${Math.floor(Math.random() * 1000)}`;
  await page.fill('#sign-username', randomUser);
  await page.fill('#sign-password', 'testpass');
  await page.click('button:has-text("Sign up")');
  await page.on('dialog', dialog => {
    expect(dialog.message()).toContain('Sign up successful.');
  });
});

test('Logout from account', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('#login2');
  await page.fill('#loginusername', '123');
  await page.fill('#loginpassword', '123');
  await page.click('button:has-text("Log in")');
  await page.click('#logout2');
  await expect(page.locator('#login2')).toBeVisible();
});

test('Check contact form', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('text=Contact');
  await page.fill('#recipient-email', 'test@example.com');
  await page.fill('#recipient-name', 'Test User');
  await page.fill('#message-text', 'This is a test message');
  await page.click('button:has-text("Send message")');
  await page.on('dialog', dialog => {
    expect(dialog.message()).toContain('Thanks for the message!!');
  });
});

test('Check About Us page', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('text=About us');
  await expect(page.locator('.video-player')).toBeVisible();
  await page.click('button:has-text("Close")');
});

test('Check empty cart', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('#cartur');
  await expect(page.locator('.success')).toHaveCount(0);
});

test('Place order successfully', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  await page.click('text=Samsung galaxy s6');
  await page.click('text=Add to cart');
  await page.click('#cartur');
  await page.click('text=Place Order');
  await page.fill('#name', 'Test User');
  await page.fill('#country', 'Ukraine');
  await page.fill('#city', 'Kyiv');
  await page.fill('#card', '1234123412341234');
  await page.fill('#month', '12');
  await page.fill('#year', '2025');
  await page.click('button:has-text("Purchase")');
  await expect(page.locator('.sweet-alert')).toContainText('Thank you for your purchase!');
});


// Configure retries and timeout in playwright.config.js
// use: { actionTimeout: 10000, navigationTimeout: 30000 }

test('Remove product from cart 1', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  
  // Add product to cart
  await page.locator('text=Samsung galaxy s6').first().click();
  await page.locator('.btn-success:has-text("Add to cart")').click();
  
  // Handle dialog
  const dialogPromise = page.waitForEvent('dialog');
  await dialogPromise;
  
  // Go to cart with explicit wait
  await page.locator('#cartur').click();
  await page.waitForURL('**/cart.html', { timeout: 10000 });
  
  // Wait for cart items to load
  await page.locator('.success').first().waitFor({ state: 'visible' });
  
  // Delete item and verify
  await page.locator('text=Delete').first().click();
  await expect(page.locator('.success')).toHaveCount(0, { timeout: 15000 });
});

test('Login with valid credentials 1', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  
  // Open login modal
  await page.locator('#login2').click();
  await page.locator('#logInModal').waitFor({ state: 'visible' });
  
  // Fill credentials
  await page.locator('#loginusername').fill('testuser');
  await page.locator('#loginpassword').fill('testpass');
  
  // Login and verify
  await page.locator('button:has-text("Log in")').click();
  await expect(page.locator('#nameofuser')).toContainText('Welcome testuser', { timeout: 10000 });
});

test('Logout from account 1', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  
  // Login first
  await page.locator('#login2').click();
  await page.locator('#logInModal').waitFor({ state: 'visible' });
  await page.locator('#loginusername').fill('testuser');
  await page.locator('#loginpassword').fill('testpass');
  await page.locator('button:has-text("Log in")').click();
  await page.locator('#nameofuser').waitFor({ state: 'visible' });
  
  // Logout and verify
  await page.locator('#logout2').click();
  await expect(page.locator('#login2')).toBeVisible();
});

test('Check contact form 1', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  
  // Open contact modal
  await page.locator('text=Contact').click();
  const modal = page.locator('#exampleModal');
  await modal.waitFor({ state: 'visible' });
  
  // Fill form
  await modal.locator('#recipient-email').fill('test@example.com');
  await modal.locator('#recipient-name').fill('Test User');
  await modal.locator('#message-text').fill('This is a test message');
  
  // Setup dialog handler BEFORE clicking send
  const dialogPromise = page.waitForEvent('dialog');
  await modal.locator('button:has-text("Send message")').click();
  
  const dialog = await dialogPromise;
  expect(dialog.message()).toContain('Thanks for the message!!');
  await dialog.accept();
});

test('Check About Us page 1', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  
  // Open About Us modal
  await page.locator('text=About us').click();
  const modal = page.locator('#videoModal');
  await modal.waitFor({ state: 'visible' });
  
  // Verify content
  await expect(modal.locator('.modal-title')).toContainText('About us');
  await expect(modal.locator('.vjs-poster')).toBeVisible();
  
  // Close modal
  await modal.locator('button:has-text("Close")').click();
  await modal.waitFor({ state: 'hidden' });
});

test('Place order successfully 1', async ({ page }) => {
  await page.goto('https://www.demoblaze.com/');
  
  // Add product
  await page.locator('text=Samsung galaxy s6').first().click();
  await page.locator('.btn-success:has-text("Add to cart")').click();
  const dialogPromise = page.waitForEvent('dialog');
  await dialogPromise;
  
  // Go to cart
  await page.locator('#cartur').click();
  await page.waitForURL('**/cart.html');
  await page.locator('text=Place Order').click();
  
  // Wait for order modal
  const orderModal = page.locator('#orderModal');
  await orderModal.waitFor({ state: 'visible' });
  
  // Fill order form
  await orderModal.locator('#name').fill('Test User');
  await orderModal.locator('#country').fill('Ukraine');
  await orderModal.locator('#city').fill('Kyiv');
  await orderModal.locator('#card').fill('1234123412341234');
  await orderModal.locator('#month').fill('12');
  await orderModal.locator('#year').fill('2025');
  
  // Purchase
  await orderModal.locator('button:has-text("Purchase")').click();
  
  // Verify success
  const successAlert = page.locator('.sweet-alert');
  await successAlert.waitFor({ state: 'visible' });
  await expect(successAlert).toContainText('Thank you for your purchase!');
  
  // Close alert
  await page.locator('button:has-text("OK")').click();
});